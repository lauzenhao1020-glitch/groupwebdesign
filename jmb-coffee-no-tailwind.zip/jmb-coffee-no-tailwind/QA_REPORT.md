# QA Report — JMB Coffee No-Tailwind Version

Automated QA was run for:

- `/home/user/jmb-coffee-no-tailwind`
- `/home/user/jmb-coffee-team-template-no-tailwind`

## Checks completed

- HTML pages load `js/app.js` exactly once
- Local CSS, JavaScript and image references exist
- No Tailwind runtime or Tailwind CSS framework file is used
- No Tailwind-style utility class patterns were detected in HTML classes
- JavaScript syntax check passed
- Home carousel works
- Home review form inserts a live review
- Menu category filter works
- Menu search works
- Menu item modal opens and closes
- Menu modal price updates for size selection
- Brew Lab price updates
- Brew Lab ticket modal opens and closes
- About roast simulator updates roast profile
- Contact form validation shows errors
- Contact valid submission shows success ticket
- Contact branch selector updates selected store
- Team template mobile navigation works
- Team template newsletter validation works

## Result

```text
QA PASS: no-tailwind site and no-tailwind team template passed.
```

## Known limitation

The Google Maps iframe may not display in sandboxed previews. It should work in a normal browser with internet access.
