# JMB Coffee — No-Tailwind Static Website

This is a plain **HTML + custom CSS + vanilla JavaScript** version of the JMB Coffee website.

## Important

This folder does **not** use Tailwind classes, Tailwind CDN, React, Vite, Bootstrap, jQuery, or any CSS framework.

All styling is written with custom semantic CSS classes in:

```text
css/styles.css
```

All JavaScript is in one file:

```text
js/app.js
```

## Pages

```text
Home.html
Menu.html
Customizer.html
About.html
Contact.html
index.html
```

## Structure

```text
jmb-coffee-no-tailwind/
├── Home.html
├── Menu.html
├── Customizer.html
├── About.html
├── Contact.html
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── app.js
└── assets/
    └── images/
```

## Features included

- Multi-page responsive website
- Mobile navigation
- Home best-seller carousel
- Home live review form
- Filterable and searchable menu catalog
- Menu product modal
- Brew Lab customizer with price/nutrition calculation
- Brew Lab recipe ticket modal
- About roast simulator
- Contact form validation
- Contact store selector
- Newsletter validation

## Run locally

```bash
cd jmb-coffee-no-tailwind
python3 -m http.server 8000
```

Open:

```text
http://localhost:8000/Home.html
```

## Note

The Google Maps iframe on `Contact.html` needs internet access and may not load inside sandboxed previews.
